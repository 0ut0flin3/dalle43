# DALL-E FOR FREE!

Use OpenAI's DALL-E for free
 
With dalle43 you can use  OpenAi's DALL-E for free

**UPDATE: dalle43 is now available for both Windows and Unix.**

To use dalle43 install `dalle43` Python module using pip : `pip install -U dalle43`

You can now generate images with DALL-E for free by running `python3 -m dalle43.dalle43` and entering the description of the image you want to generate. The images will be saved in the `/home/USER/Pictures/generated_images` folder

Enjoy! <3

![Screenshot from 2023-03-20 02-32-00](https://user-images.githubusercontent.com/114559605/226227527-6a9eb333-ebea-44bf-88b7-d945022d74ae.png)
![Screenshot from 2023-03-20 02-32-03](https://user-images.githubusercontent.com/114559605/226227544-66d2e956-8bd6-43d5-8397-41e720674b7a.png)