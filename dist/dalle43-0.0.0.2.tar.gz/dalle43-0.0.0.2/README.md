# DALL-E FOR FREE!
Use OpenAI's DALL-E for free, unlimited and without politically correct restrictions
 
With dalle43 you can use  OpenAi's DALL-E for free, this means that **you will not need any api-key to generate the images** but you can generate as many as you want, for free, and without censorship

dalle43 is only available for Linux systems.

To use dalle43 follow the instructions below:

1) install xvfb (mandatory) : `sudo apt-get install xvfb`
2) install dalle43 : `pip install dalle43`

You can now generate images with DALL-E for free by running `python3 -m dalle43.dalle43` and entering the description of the image you want to generate. The images will be saved in the `/home/USER/Pictures/generated_images` folder

Enjoy! <3
